const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
const PORT = 8000;

// Middleware
app.use(cors());
app.use(express.json());

// ESP32 Device Configuration
const ESP32_IP = '192.168.4.168`'; // Replace with your ESP32's IP address
const ESP32_PORT = 80;
const BASE_URL = `http://${ESP32_IP}:${ESP32_PORT}`;

// Routes

// Serve the main control page
app.get('/', (req, res) => {
  res.send(`<h1>ESP32 Control Server</h1>
            <p>Use endpoints to interact with the ESP32 device.</p>`);
});

// Start monitoring on the ESP32
app.get('/start', async (req, res) => {
  try {
    const response = await axios.get(`${BASE_URL}/start`);
    res.status(200).send(response.data);
  } catch (error) {
    console.error('Error starting monitoring:', error.message);
    res.status(500).send('Failed to start monitoring.');
  }
});

// Stop monitoring on the ESP32
app.get('/stop', async (req, res) => {
  try {
    const response = await axios.get(`${BASE_URL}/stop`);
    res.status(200).send(response.data);
  } catch (error) {
    console.error('Error stopping monitoring:', error.message);
    res.status(500).send('Failed to stop monitoring.');
  }
});

// Get real-time data from the ESP32
app.get('/data', async (req, res) => {
  try {
    const response = await axios.get(`${BASE_URL}/data`);
    res.status(200).json(response.data);
  } catch (error) {
    console.error('Error fetching data:', error.message);
    res.status(500).send('Failed to fetch data.');
  }
});

// Start the Node.js server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
