const express = require('express');
const axios = require('axios');
const app = express();

const ESP32_IP = 'http://192.168.1.184'; 
const PORT = process.env.PORT || 3000;

app.use(express.json());


app.post('/motor/start', async (req, res) => {
  try {
    const response = await axios.post(`${ESP32_IP}/motor/start`);
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: 'Failed to start motor' });
  }
});

app.post('/motor/stop', async (req, res) => {
  try {
    const response = await axios.post(`${ESP32_IP}/motor/stop`);
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: 'Failed to stop motor' });
  }
});

app.post('/motor/speed', async (req, res) => {
  try {
    const speed = req.body.speed;
    const response = await axios.post(`${ESP32_IP}/motor/speed`, null, {
      params: { speed },
    });
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: 'Failed to set motor speed' });
  }
});

app.listen(PORT, () => {
  console.log(`Proxy server running on port ${PORT}`);
});
